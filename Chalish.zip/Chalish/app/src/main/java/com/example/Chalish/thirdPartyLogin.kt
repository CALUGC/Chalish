package com.example.Chalish

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.util.StatsLog.logEvent
import android.widget.TextView
import android.widget.Toast
import com.facebook.CallbackManager
import com.facebook.FacebookCallback
import com.facebook.login.LoginResult
import com.firebase.ui.auth.AuthUI
import com.firebase.ui.auth.IdpResponse
import com.google.firebase.FirebaseApp
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.auth.*
import kotlin.math.log

class thirdPartyLogin : AppCompatActivity() {
    lateinit var firebaseUser : FirebaseUser

    private var RC_SIGN_IN = 200
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_third_party_login)

        val firebaseAnalytics = FirebaseAnalytics.getInstance(this)
        savedInstanceState?.putString(FirebaseAnalytics.Param.METHOD, FirebaseAnalytics.Event.LOGIN)
        firebaseAnalytics.logEvent(FirebaseAnalytics.Event.LOGIN, savedInstanceState)

        signOut()
        val authProvider: List<AuthUI.IdpConfig> = listOf(
            AuthUI.IdpConfig.FacebookBuilder().build(),
            AuthUI.IdpConfig.GoogleBuilder().build()
        )

        val authListener: FirebaseAuth.AuthStateListener =
            FirebaseAuth.AuthStateListener { auth: FirebaseAuth ->
                val user: FirebaseUser? = auth.currentUser
                Log.d("fbc","fuck")
                if (user == null) {
                    val intent = AuthUI.getInstance(FirebaseApp.getInstance())
                        .createSignInIntentBuilder()
                        .setAvailableProviders(authProvider)
                        .setAlwaysShowSignInMethodScreen(true)
                        .setIsSmartLockEnabled(false)
                        .build()
                    startActivityForResult(intent, this.RC_SIGN_IN)
                } else {
                    this.firebaseUser = user
                    displayInfo()
                }
            }

        FirebaseAuth.getInstance(FirebaseApp.getInstance()).addAuthStateListener(authListener)
    }


    private fun displayInfo() {
        val txtUserName = findViewById<TextView>(R.id.txtUserName)
        txtUserName.text = firebaseUser?.displayName
    }

    private fun signOut() {
        AuthUI.getInstance()
            .signOut(this)
            .addOnSuccessListener {
                Toast.makeText(applicationContext, "已登出", Toast.LENGTH_SHORT).show()
            }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        Log.d("data",data?.extras.toString())
        Toast.makeText(applicationContext, "已回彈$requestCode", Toast.LENGTH_SHORT).show()
        if (requestCode == this.RC_SIGN_IN) {
            if (resultCode != Activity.RESULT_OK) {
                val response = IdpResponse.fromResultIntent(data)
                Toast.makeText(applicationContext, response?.error?.errorCode.toString(), Toast.LENGTH_SHORT).show()
            }
            else{
                Toast.makeText(applicationContext, "已成功登入$requestCode", Toast.LENGTH_SHORT).show()
            }

        }
    }
}
